rm ./playlists/*
rm ./logs/*
python portCleaner.py